import React from "react";

 function StockAnalysisCard({ data }) {
  const { ticker, agent_opinions, final_recommendation } = data;

  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-md p-6 space-y-4">
      <h2 className="text-2xl font-bold text-blue-700">{ticker} Stock Overview</h2>

      {/* Final Recommendation */}
      <div className="text-lg font-semibold text-gray-700">
        📌 Final Recommendation: 
        <span className={`ml-2 px-3 py-1 rounded-full ${
          final_recommendation === "buy"
            ? "bg-green-100 text-green-800"
            : final_recommendation === "sell"
            ? "bg-red-100 text-red-800"
            : "bg-yellow-100 text-yellow-800"
        }`}>
          {final_recommendation.toUpperCase()}
        </span>
      </div>

      {/* Agent Opinions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {agent_opinions.map((op, index) => (
          <div key={index} className="border rounded-lg p-4 bg-gray-50">
            <h3 className="text-md font-semibold text-gray-800">
              🧠 Analyst {index + 1} — {op.ticker || "AAPL"}
            </h3>
            <p className="text-sm text-gray-600 mt-2">
              <strong>📝 Summary:</strong> {op.reason}
            </p>
            <p className="mt-2 text-sm">
              <strong>📉 Recommendation:</strong> {op.recommendation}
            </p>

            {/* Sentiment Summary if news present */}
            {op.sentiment_summary && (
              <div className="mt-4">
                <p className="text-sm font-medium">📰 News Sentiment:</p>
                <ul className="ml-4 text-sm text-gray-700 list-disc">
                  <li><strong>Positive:</strong> {op.sentiment_summary.positive}</li>
                  <li><strong>Neutral:</strong> {op.sentiment_summary.neutral}</li>
                  <li><strong>Negative:</strong> {op.sentiment_summary.negative}</li>
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}


export default StockAnalysisCard;