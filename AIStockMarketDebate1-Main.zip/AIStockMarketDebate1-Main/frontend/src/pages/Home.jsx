import React from 'react';
import Navbar from '../pages/Navbar';
import shiv from "../assets/home1.png"


const Home = () => {
  return (
    <div className='w-full px-0'>
      <Navbar />

    <br/><br/> <br/><br/>
    {/* Hero Section */}
    <section
        className=" relative bg-cover bg-no-repeat py-28 px-0 border border-blue"
        style={{ backgroundImage: `url(${shiv})` }}
      >
        {/* Dark Gradient Overlay */}
        <div className="absolute inset-0 bg-black/60"></div>

        {/* Content */}
        <div className="relative z-10 container px-2 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            AI-Powered Stock Debate System
          </h1>
          <p className="text-lg md:text-xl mb-6">
            Let Virtual Analysts Debate & Deliver Final Recommendations
          </p>
          <a
            href="/analyze"
            className="inline-block px-6 py-3 bg-yellow-400 text-black font-semibold rounded hover:bg-yellow-300 transition"
          >
            Start Analyzing
          </a>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-10">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
  { 
    title: "Choose Market Type", 
    desc: "Select the market segment you're interested in (e.g., NSE, BSE, NYSE, Crypto)." 
  },
  { 
    title: "Select Timeframe", 
    desc: "Define your investment horizon (e.g., Intraday, Short-Term, Long-Term)." 
  },
  { 
    title: "Set Risk Appetite", 
    desc: "Choose your risk level – Low, Moderate, or High – to tailor stock recommendations." 
  },
  { 
    title: "Top 3 Stocks Identified", 
    desc: "Our AI scans the market, filters by trends, fundamentals, and technicals to pick 3 best-fit stocks." 
  },
  { 
    title: "Analysts Debate", 
    desc: "AI Analysts simulate bullish, bearish, and neutral perspectives for each stock." 
  },
  { 
    title: "Moderator Summarizes", 
    desc: "The AI Moderator reviews all debates and summarizes with clarity and balance." 
  },
  { 
    title: "Final Investment Verdict", 
    desc: "A comprehensive recommendation including rationale, timing, and caution points." 
  }
]
.map((step, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition">
                <div className="text-3xl font-bold text-blue-600 mb-4">{index + 1}</div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-10">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: "🧠", title: "AI-Driven Debate", desc: "Multiple AI specialists analyze each stock" },
              { icon: "🔍", title: "Real-Time Analysis", desc: "News & sentiment analysis using FinBERT" },
              { icon: "📈", title: "Technical Indicators", desc: "MACD, RSI, and other metrics" },
              { icon: "⚖️", title: "Risk Profiling", desc: "Comprehensive risk evaluation" },
              { icon: "✅", title: "Explainable AI", desc: "Understand the reasoning behind suggestions" },
            ].map((feature, idx) => (
              <div key={idx} className="bg-gray-50 p-6 rounded-lg shadow hover:shadow-md transition">
                <div className="text-4xl mb-3">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Analysts Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-10">Meet Your Virtual Analysts</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {[
              { img: "market.png", title: "Market Researcher", desc: "News & Sentiment via FinBERT" },
              { img: "fundamental.jpg", title: "Fundamental Analyst", desc: "Price Prediction via LSTM/ARIMA" },
              { img: "technical.jpg", title: "Technical Analyst", desc: "RSI, MACD, SMA Indicators" },
              { img: "risk.jpg", title: "Risk Analyst", desc: "Volatility, Beta, Value at Risk" },
              { img: "moderator.jpg", title: "AI Moderator", desc: "Combines All Opinions for Verdict" },
            ].map((analyst, idx) => (
              <div key={idx} className="bg-white p-4 rounded-lg shadow-md">
                <img src={`/src/assets/${analyst.img}`} alt={analyst.title} className="w-full h-32 object-cover rounded mb-3" />
                <h3 className="text-lg font-semibold">{analyst.title}</h3>
                <p className="text-gray-600 text-sm">{analyst.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-10 text-center">FAQs</h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {[
              { q: "What data is used for analysis?", a: "We use real-time stock data, news, and financial indicators from trusted APIs." },
              { q: "Is this recommendation reliable?", a: "Each component provides confidence scores. The final decision is based on weighted logic." },
              { q: "Is my input data saved?", a: "No. All predictions happen in-session without storing your inputs." },
              { q: "Is it free?", a: "Yes, this tool is free for educational and demo purposes." },
            ].map((faq, idx) => (
              <details key={idx} className="bg-gray-100 p-4 rounded-lg">
                <summary className="cursor-pointer text-lg font-semibold">{faq.q}</summary>
                <p className="text-gray-700 mt-2">{faq.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-6 text-center">
        <p>
          &copy; 2025 Stock Debate System |{" "}
          <a href="/about" className="underline hover:text-yellow-400">About</a> |{" "}
          <a href="/admin" className="underline hover:text-yellow-400">Admin Panel</a>
        </p>
      </footer>
    </div>
  );
};

export default Home;
