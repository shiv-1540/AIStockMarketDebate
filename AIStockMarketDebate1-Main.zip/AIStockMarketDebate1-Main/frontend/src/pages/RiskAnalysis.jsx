import React, { useEffect, useState } from 'react';
import axios from 'axios';

const RiskAnalysis = ({ ticker }) => {
  const [risk, setRisk] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!ticker) return;

    const fetchStockData = async () => {
      setLoading(true);
      try {
        const response = await axios.post(`http://localhost:5000/api/analyze-risk`, {
          ticker: ticker,
        });
        setRisk(response.data.analysis);
        setError('');
      } catch (err) {
        setError('Failed to fetch risk analysis.');
        setRisk('');
      } finally {
        setLoading(false);
      }
    };

    fetchStockData();
  }, [ticker]);

  return (
    <div className="max-w-2xl mx-auto mt-6 p-6 bg-white rounded-xl shadow-md border border-gray-200">
      <h2 className="text-xl font-semibold mb-4 text-gray-800">📊 Risk Analysis for <span className="text-blue-600">{ticker}</span></h2>

      {loading && (
        <p className="text-gray-500 italic">Analyzing risk, please wait...</p>
      )}

      {error && (
        <p className="text-red-500">{error}</p>
      )}

      {!loading && !error && (
        <div className="bg-gray-50 border-l-4 border-yellow-400 p-4 text-gray-700">
          <p>{risk}</p>
        </div>
      )}
    </div>
  );
};

export default RiskAnalysis;
