import React, { useState } from 'react';
import '../styles/Analyze.css';
import Navbar from '../pages/Navbar';

const Analyze = () => {
  const [ticker, setTicker] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsAnalyzing(true);
    
    // Simulate analysis (replace with actual API call)
    setTimeout(() => {
      setAnalysisResult({
        ticker: ticker.toUpperCase(),
        recommendation: 'BUY',
        confidence: '85%',
        debate: [
          {
            analyst: 'Market Researcher',
            opinion: 'Positive sentiment detected in recent news (FinBERT score: 0.78)',
            confidence: '82%'
          },
          {
            analyst: 'Fundamental Analyst',
            opinion: 'Undervalued by 15% based on LSTM price prediction',
            confidence: '88%'
          },
          {
            analyst: 'Technical Analyst',
            opinion: 'Strong buy signals from RSI(28) and MACD crossover',
            confidence: '79%'
          },
          {
            analyst: 'Risk Analyst',
            opinion: 'Low volatility (Beta: 0.92) with favorable risk/reward',
            confidence: '83%'
          }
        ],
        summary: 'The consensus among analysts is strongly positive, with multiple indicators suggesting this is a good buying opportunity. The AI Moderator weighted all opinions and technical factors to arrive at this recommendation.'
      });
      setIsAnalyzing(false);
    }, 3000);
  };

  return (
    <>
      <Navbar />
      <div className="analyze-container">
        <header className="analyze-header">
          <h1>Stock Analysis</h1>
          <p>Enter a stock ticker to begin the AI-powered debate</p>
        </header>

        <section className="analysis-form">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="ticker">Stock Ticker</label>
              <input
                type="text"
                id="ticker"
                value={ticker}
                onChange={(e) => setTicker(e.target.value)}
                placeholder="e.g. AAPL, MSFT, TSLA"
                required
              />
              <button type="submit" disabled={isAnalyzing}>
                {isAnalyzing ? 'Analyzing...' : 'Start Analysis'}
              </button>
            </div>
          </form>
        </section>

        {isAnalyzing && (
          <section className="analysis-progress">
            <h2>AI Analysts Are Debating...</h2>
            <div className="analysts-working">
              <div className="analyst">
                <img src="/images/market.png" alt="Market Researcher" />
                <p>Analyzing news...</p>
              </div>
              <div className="analyst">
                <img src="/images/fundamental.png" alt="Fundamental Analyst" />
                <p>Running models...</p>
              </div>
              <div className="analyst">
                <img src="/images/technical.png" alt="Technical Analyst" />
                <p>Checking charts...</p>
              </div>
              <div className="analyst">
                <img src="/images/risk.png" alt="Risk Analyst" />
                <p>Assessing risk...</p>
              </div>
            </div>
            <div className="progress-bar">
              <div className="progress"></div>
            </div>
          </section>
        )}

        {analysisResult && (
          <section className="analysis-results">
            <div className="result-header">
              <h2>Analysis Results for {analysisResult.ticker}</h2>
              <div className={`recommendation ${analysisResult.recommendation.toLowerCase()}`}>
                {analysisResult.recommendation}
                <span>Confidence: {analysisResult.confidence}</span>
              </div>
            </div>

            <div className="debate-results">
              <h3>Analyst Debate</h3>
              <div className="debate-cards">
                {analysisResult.debate.map((analyst, index) => (
                  <div className="debate-card" key={index}>
                    <h4>{analyst.analyst}</h4>
                    <p>{analyst.opinion}</p>
                    <div className="confidence">Confidence: {analyst.confidence}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="summary">
              <h3>AI Moderator Summary</h3>
              <p>{analysisResult.summary}</p>
            </div>

            <div className="actions">
              <button className="save-btn">Save Analysis</button>
              <button className="new-btn">New Analysis</button>
            </div>
          </section>
        )}

        <footer className="analyze-footer">
          <p>&copy; 2025 Stock Debate System | <a href="/about">About</a> | <a href="/admin">Admin Panel</a></p>
        </footer>
      </div>
    </>
  );
};

export default Analyze;