import { useState } from "react";
import Navbar from "./Navbar";
import TechnicalAnalysis from "./TechnicalAnalysis";
import StockAnalysisCard from "../components/StockAnalysisCard";
// import MiniChart from "../components/MiniChart";
// import PredictionScore from "../components/PredictionScore";

const agentNames = [
  "RISK ANALYST AGENT",
  " MARKET RESEARCH ANALYST",
  "TECHNICAL ANALYST AGENT",
  // " Market Sentiment Aggregator"
];

const stockTickers = [
  // "AAPL",   // Apple
  // "MSFT",   // Microsoft
  // "TSLA",   // Tesla
  // // "GOOGL",  // Alphabet (Google)
  // "AMZN",   // Amazon
  // "META",   // Meta (Facebook)
  // "NVDA",   // Nvidia
  // "NFLX",   // Netflix
  "INTC",   // Intel
  // "AMD",    // Advanced Micro Devices
  "IBM",    // IBM
  // "ORCL",   // Oracle
  // "ADBE",   // Adobe
  // "CRM",    // Salesforce
  // "BABA",   // Alibaba
  "JNJ",    // Johnson & Johnson
  // "PFE",    // Pfizer
  // "MRK",    // Merck
  // "UNH",    // UnitedHealth
  // "XOM",    // ExxonMobil
  // "CVX",    // Chevron
  // "BP",     // British Petroleum
  "WMT",    // Walmart
  "TGT",    // Target
  // "KO",     // Coca-Cola
  "PEP",    // PepsiCo
  "DIS",    // Disney
  "BA",     // Boeing
  "NKE",    // Nike
  "UBER",   // Uber
  // "LYFT",   // Lyft
  // "SHOP",   // Shopify
  "SQ",     // Block (formerly Square)
  "PYPL",   // PayPal
  // "GS",     // Goldman Sachs
  "JPM",    // JPMorgan Chase
  // "BAC",    // Bank of America
  // "C",      // Citigroup
  // "TSM",    // Taiwan Semiconductor
  // "V",      // Visa
  "MA"      // Mastercard
];
const stockTickers1 = [
  "AAPL",   // Apple
  "MSFT",   // Microsoft
  "TSLA",   // Tesla
  "GOOGL",  // Alphabet (Google)
  "AMZN",   // Amazon
  "META",   // Meta (Facebook)
  "NVDA",   // Nvidia
  "NFLX",   // Netflix
  "INTC",   // Intel
  "AMD",    // Advanced Micro Devices
  "IBM",    // IBM
  "ORCL",   // Oracle
  "ADBE",   // Adobe
  "CRM",    // Salesforce
  "BABA",   // Alibaba
  "JNJ",    // Johnson & Johnson
  "PFE",    // Pfizer
  "MRK",    // Merck
  "UNH",    // UnitedHealth
  "XOM",    // ExxonMobil
  "CVX",    // Chevron
   "BP",     // British Petroleum
  "WMT",    // Walmart
  "TGT",    // Target
   "KO",     // Coca-Cola
  "PEP",    // PepsiCo
  "DIS",    // Disney
  "BA",     // Boeing
  "NKE",    // Nike
  "UBER",   // Uber
   "LYFT",   // Lyft
  "SHOP",   // Shopify
  "SQ",     // Block (formerly Square)
  "PYPL",   // PayPal
   "GS",     // Goldman Sachs
  "JPM",    // JPMorgan Chase
  "BAC",    // Bank of America
  "C",      // Citigroup
  "TSM",    // Taiwan Semiconductor
   "V",      // Visa
  "MA"      // Mastercard
];

// Market type object with categorized assets
const marketType = {
  Stocks: [
    "AAPL",  // Apple Inc.
    "MSFT",  // Microsoft Corp.
    "TSLA",  // Tesla Inc.
    "NVDA",  // Nvidia Corp.
    "AMZN",  // Amazon.com Inc.
    "META",  // Meta Platforms Inc.
    "GOOG",  // Alphabet Inc.
    "JPM",   // JPMorgan Chase & Co.
    "WMT",   // Walmart Inc.
    "UNH"    // UnitedHealth Group
  ],
  Crypto: [
    "BTC",    // Bitcoin
    "ETH",    // Ethereum
    "BNB",    // Binance Coin
    "SOL",    // Solana
    "ADA",    // Cardano
    "XRP",    // Ripple
    "DOGE",   // Dogecoin
    "MATIC",  // Polygon
    "AVAX",   // Avalanche
    "DOT"     // Polkadot
  ],
  ETFs: [
    "SPY",    // S&P 500 ETF
    "QQQ",    // Nasdaq-100 ETF
    "VTI",    // Total Stock Market ETF
    "ARKK",   // ARK Innovation ETF
    "DIA",    // Dow Jones ETF
    "IWM",    // Russell 2000 ETF
    "XLF",    // Financial Sector ETF
    "XLK",    // Technology Sector ETF
    "XLE",    // Energy Sector ETF
    "TLT"     // Treasury Bond ETF
  ],
  Forex: [
    "EUR/USD",  // Euro / US Dollar
    "USD/JPY",  // US Dollar / Japanese Yen
    "GBP/USD",  // British Pound / US Dollar
    "AUD/USD",  // Australian Dollar / US Dollar
    "USD/CHF",  // US Dollar / Swiss Franc
    "USD/CAD",  // US Dollar / Canadian Dollar
    "NZD/USD",  // New Zealand Dollar / US Dollar
    "EUR/GBP",  // Euro / British Pound
    "EUR/JPY",  // Euro / Japanese Yen
    "GBP/JPY"   // British Pound / Japanese Yen
  ]
};

// 🔍 Function to get asset list by market type
function getAssetsByMarketType(type) {
  return marketType[type] || [];
}


function StockDebateSystem() {
  const [inputs, setInputs] = useState({ market: "", risk: "", timeframe: "" });
  const [results, setResults] = useState([]);

  const handleChange = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
  };

  const getRandomStocks = (tickers, count = 3) => {
    const shuffled = [...tickers].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };
  
  const handleCheckStock = async () => {
    try {
      const selectedTickers = getRandomStocks(stockTickers, 3);
  
      const responses = await Promise.all(
        selectedTickers.map(ticker =>
          fetch(`http://127.0.0.1:5000/api/stock/${ticker}`).then(res => res.json())
        )
      );
  
      setResults(responses);
    } catch (err) {
      console.error("Error fetching stock data:", err);
    }
  };

 
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 py-10 px-4">
        <Navbar/>

        <br/>   <br/>   <br/>  <br/>
        <div className="max-w-6xl mx-auto px-4 py-10">
        <h1 className="text-4xl font-extrabold text-center text-blue-800 mb-8">
            🤖 AI Stock Debate System
        </h1>

        {/* Input Form Card */}
        <div className="bg-white rounded-xl shadow-md p-8 space-y-6 border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Market</label>
                <select
                  name="market"
                  onChange={handleChange}
                  className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Market</option>
                  <option value="Stocks">Stocks</option>
                  <option value="Crypto">Crypto</option>
                  <option value="ETFs">ETFs (Exchange Traded Funds)</option>
                  <option value="Forex">Forex (Currency Pairs) </option>
                </select>

            </div>

            <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Risk Level</label>
                <select
                name="risk"
                onChange={handleChange}
                className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                <option value="">Select Risk Level</option>
                <option value="Low">Conservative</option>
                <option value="Medium">Moderate</option>
                <option value="High">Aggressive</option>
                </select>
            </div>

            <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Timeframe</label>
                <select
                name="timeframe"
                onChange={handleChange}
                className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                <option value="">Select Timeframe</option>
                <option value="Intraday">This Week</option>
                <option value="Short-Term">This Month</option>
                <option value="Long-Term">Long Term</option>
                </select>
            </div>
            </div>

            <button
            onClick={handleCheckStock}
            className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition duration-200"
            >
            🔍 Get Stock Recommendations
            </button>
        </div>
        <br/> <br/>

         {/* Button to Trigger Analysis
            <div className="text-center mt-8">
              <button
                onClick={handleCheckStock}
                className="px-6 py-3 bg-blue-600 text-white rounded-full shadow-md hover:bg-blue-700 transition"
              >
                🔍 Analyze Random Stocks
              </button>
            </div>

            {/* Analysis Result Cards */}
            {/* <div className="mt-10 grid gap-8">
              {results.map((stockData, idx) => (
                <StockAnalysisCard key={idx} data={stockData} />
              ))}
            </div> */} 
        
       {/* Results Section */}
    <div className="w-full space-y-10 mt-10">
      {/* Header: Top 3 Stocks */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800">🔍 Top 3 Selected Stocks</h2>
        <div className="flex justify-center gap-4 mt-4">
          {results.map((result, index) => (
            <span
              key={index}
              className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-semibold shadow-sm border border-blue-200"
            >
              {result.ticker}
            </span>

          
          ))}
        </div>
      </div>

    {/* Stock Result Cards */}
{results.map((result, stockIdx) => (
  <div
    key={stockIdx}
    className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 transition hover:shadow-xl"
  >
    {/* Final Recommendation */}
    <h3 className="text-2xl font-bold text-gray-900 mb-6">
      📌 Final Recommendation for <span className="text-blue-600">{result.ticker}</span>:{" "}
      <span
        className={`uppercase ml-2 font-bold ${
          result.final_recommendation === "buy"
            ? "text-green-600"
            : result.final_recommendation === "sell"
            ? "text-red-600"
            : "text-yellow-600"
        }`}
      >
        {result.final_recommendation}
      </span>
    </h3>

    {/* Agent Opinions */}
    <div className="grid md:grid-cols-2 gap-6">
      {result.agent_opinions.map((opinion, idx) => (
        <div
          key={idx}
          className="border border-gray-300 rounded-lg p-4 bg-gray-50 hover:bg-gray-100 transition"
        >
          <p className="text-gray-500 text-md font-bold mb-1">
            {agentNames[idx] || `Agent #${idx + 1}`}
          </p>

          <p className="text-gray-800 text-base">
            <strong>Recommendation:</strong>{" "}
            <span className="capitalize text-blue-700 font-medium">
              {opinion.recommendation}
            </span>
          </p>

          <p className="text-gray-700 mt-1">
            <strong>Reason:</strong> {opinion.reason}
          </p>

          {/* News Sentiment */}
          {opinion.sentiment_summary && (
            <div className="mt-4">
              <p className="font-semibold text-gray-700 text-sm">📰 News Sentiment Summary</p>
              <p className="text-sm text-gray-800">
                Dominant Sentiment:{" "}
                <span className="capitalize font-semibold text-purple-600">
                  {opinion.sentiment_summary.dominant_sentiment || "neutral"}
                </span>
              </p>
              <ul className="list-disc list-inside mt-2 text-sm text-gray-700 space-y-1">
                {opinion.news?.map((item, index) => (
                  <li key={index}>
                    <span className="font-medium">{item.headline}</span> –{" "}
                    <span className="italic">{item.sentiment}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ))}
    </div>

    {/* Technical Analyst Section */}
    <div className="mt-10 p-6 border rounded-lg bg-blue-50">
      <h4 className="text-lg font-bold text-blue-700 mb-2">📉 Technical Analyst Insights</h4>
      {/* <ul className="text-sm text-gray-700 list-disc list-inside">
        <li><strong>Entry Price:</strong> $152.00</li>
        <li><strong>Stop Loss:</strong> $147.50</li>
        <li><strong>Target Price:</strong> $168.00</li>
      </ul>
      <p className="text-gray-800 mt-2">
        Based on technical chart patterns, ORCL is forming a bullish flag with potential upside. Watch for confirmation above $155. MACD crossover and RSI at 55 support this setup.
      </p> */}
      <TechnicalAnalysis ticker={result.ticker} />
    </div>

        {/* Moderator Summary Section */}
        <div className="mt-10 p-6 border rounded-lg bg-green-50">
          <h4 className="text-lg font-bold text-green-700 mb-3">📋 Moderator Agent Summary</h4>
          <p className="text-gray-800 text-sm mb-2">Top 3 Picks This Week:</p>
          <ol className="text-sm text-gray-700 list-decimal list-inside space-y-1">
            <li>
              <strong>INTC</strong> – Strong earnings momentum, entry @ $325, SL @ $310, target @ $350
            </li>
            <li>
              <strong>IBM</strong> – AI sector dominance, entry @ $865, SL @ $830, target @ $920
            </li>
            <li>
              <strong>WMT</strong> – Cloud expansion upside, entry @ $152, SL @ $147.5, target @ $168
            </li>
          </ol>
          <p className="text-gray-800 mt-3 text-sm">
            These stocks have been chosen based on consistent earnings growth, industry momentum, and favorable technical setups. Risks include sector volatility and earnings surprises.
          </p>
        </div>
      </div>
    ))}
    </div>
      </div>
    </div>
  );
}

export default StockDebateSystem;
