import React from 'react';
import '../styles/About.css';
import Navbar from '../pages/Navbar';

const About = () => {
  return (
    <>
      <Navbar />
      <div className="about-container">
        <header className="about-header">
          <h1>About the Stock Debate System</h1>
          <p>Empowering investors with explainable, AI-powered insights.</p>
        </header>

        <section className="mission">
          <h2>Our Mission</h2>
          <div className="icon">🎯</div>
          <p>
            We aim to democratize financial analysis by simulating expert-level stock debates using cutting-edge AI agents.
            From market sentiment to technical charts, we aggregate diverse perspectives into a single verdict — all in real-time.
          </p>
        </section>

        <section className="what-we-do">
          <h2>What We Do</h2>
          <div className="icon">🔬</div>
          <div className="features-grid">
            <div className="feature-item">
              <div className="feature-icon">📊</div>
              <h3>Technical Indicators</h3>
              <p>Integrate MACD, RSI, and SMA for comprehensive analysis</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">🧠</div>
              <h3>Price Forecasting</h3>
              <p>Use LSTM and statistical models for accurate predictions</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">📰</div>
              <h3>Sentiment Analysis</h3>
              <p>Analyze financial news using NLP techniques</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">📉</div>
              <h3>Risk Assessment</h3>
              <p>Evaluate portfolio risk and volatility metrics</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">🤖</div>
              <h3>AI Moderation</h3>
              <p>Coordinate debates among specialized virtual agents</p>
            </div>
          </div>
        </section>

        <section className="team">
          <h2>The Virtual Team</h2>
          <div className="icon">👥</div>
          <div className="team-grid">
            <div className="team-card">
              <h3>Market Researcher</h3>
              <p>Performs sentiment and news analysis using FinBERT and APIs.</p>
            </div>
            <div className="team-card">
              <h3>Fundamental Analyst</h3>
              <p>Forecasts prices using time series models like LSTM and ARIMA.</p>
            </div>
            <div className="team-card">
              <h3>Technical Analyst</h3>
              <p>Identifies chart-based patterns and signal indicators.</p>
            </div>
            <div className="team-card">
              <h3>Risk Manager</h3>
              <p>Calculates Value at Risk, beta, and volatility metrics.</p>
            </div>
            <div className="team-card">
              <h3>AI Moderator</h3>
              <p>Listens to all agents and summarizes a final verdict.</p>
            </div>
          </div>
        </section>

        <section className="tech-stack">
          <h2>Tech Stack</h2>
          <div className="icon">🛠️</div>
          <div className="tech-grid">
            <div className="tech-card">React</div>
            <div className="tech-card">Node.js</div>
            <div className="tech-card">MongoDB</div>
            <div className="tech-card">Python</div>
            <div className="tech-card">LSTM</div>
            <div className="tech-card">FinBERT</div>
            <div className="tech-card">TensorFlow</div>
            <div className="tech-card">AWS</div>
          </div>
        </section>

        <footer className="about-footer">
          <p>&copy; 2025 Stock Market Debate System. All rights reserved.</p>
        </footer>
      </div>
    </>
  );
};

export default About;