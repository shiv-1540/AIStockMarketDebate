import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const TechnicalAnalysis = ({ ticker }) => {
  const [stockData, setStockData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStockData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/stock-data?ticker=${ticker}&period=3mo&interval=1d`);
        setStockData(response.data.data);
        setLoading(false);
      } catch (err) {
        setError(err);
        setLoading(false);
      }
    };

    fetchStockData();
  }, [ticker]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error fetching data: {error.message}</div>;

  const labels = stockData.map(item => new Date(item.Date).toLocaleDateString());
  const closePrices = stockData.map(item => item.Close);
  const highPrices = stockData.map(item => item.High);
  const lowPrices = stockData.map(item => item.Low);
  const openPrices = stockData.map(item => item.Open);
  const volumePrices = stockData.map(item => item.Volume);
  


  const data = {
    labels,
    datasets: [
      {
        label: 'Close Price',
        data: closePrices,
        borderColor: 'rgb(242, 200, 12)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        fill: true,
      },
      {
        label: 'High Price',
        data: highPrices,
        borderColor: 'rgb(164, 9, 9)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        fill: false,
      },
      {
        label: 'Low Price',
        data: lowPrices,
        borderColor: 'rgba(255, 206, 86, 1)',
        backgroundColor: 'rgba(255, 206, 86, 0.2)',
        fill: false,
      },
      {
        label: 'Open Price',
        data: openPrices,
        borderColor: 'rgba(54, 162, 235, 1)',
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        fill: false,
      },
    
    ],
  };

  const options = {
    responsive: true,
    scales: {
      x: {
        title: {
          display: true,
          text: 'Date',
        },
      },
      y: {
        title: {
          display: true,
          text: 'Price (USD)',
        },
      },
    },
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Technical Analysis for {ticker}</h2>
      <div>
          <Line data={data} options={options} />
      </div>
      
       <div>
        
  {/* <h3 style="margin-bottom: 12px; color: #333;">📈 Technical Indicators</h3>
  
  <div style="margin-bottom: 10px;">
    <strong>Average RSI:</strong>
    <span style="color: #007bff; font-weight: bold;">54.38</span>
  </div>

  <div style="margin-bottom: 10px;">
    <strong>MACD Line:</strong>
    <span style="color: #28a745; font-weight: bold;">1.23</span>
  </div>

  <div style="margin-bottom: 10px;">
    <strong>Signal Line:</strong>
    <span style="color: #dc3545; font-weight: bold;">1.10</span>
 

 
</div>

     
     */}
       </div>
        </div>

  );
};

export default TechnicalAnalysis;
