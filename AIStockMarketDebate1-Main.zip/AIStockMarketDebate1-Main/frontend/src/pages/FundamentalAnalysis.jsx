import React, { useState } from 'react';

function FundamentalAnalysis() {
  const [ticker, setTicker] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const fetchFundamentals = async () => {
    try {
      const response = await fetch(`http://127.0.0.1:5000/fundamentals/${ticker}`);
      const result = await response.json();

      if (result.error) {
        setError(result.error);
        setData(null);
      } else {
        setData(result);
        setError('');
      }
    } catch (err) {
      setError('Error fetching data');
      setData(null);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 mt-10 shadow-lg rounded-2xl bg-white">
      <h2 className="text-2xl font-bold mb-4 text-center text-blue-600">Fundamental Analysis</h2>

      <div className="flex items-center gap-2 mb-4">
        <input
          type="text"
          placeholder="Enter ticker (e.g. AAPL)"
          value={ticker}
          onChange={(e) => setTicker(e.target.value)}
          className="flex-1 border p-2 rounded-lg shadow"
        />
        <button
          onClick={fetchFundamentals}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          Fetch
        </button>
      </div>

      {error && <p className="text-red-500">{error}</p>}

      {data && (
        <div className="bg-gray-50 p-4 rounded-lg shadow-md">
          <p><strong>Ticker:</strong> {data.ticker}</p>
          <p><strong>Earnings:</strong> {data.earnings}</p>
          <p><strong>Net Income:</strong> ₹{(data.net_income / 1e7).toFixed(2)} Cr</p>
          <p><strong>P/E Ratio:</strong> {data.pe_ratio}</p>
          <p><strong>Industry Info:</strong> {data.industry_info}</p>
        </div>
      )}
    </div>
  );
}

export default FundamentalAnalysis;
