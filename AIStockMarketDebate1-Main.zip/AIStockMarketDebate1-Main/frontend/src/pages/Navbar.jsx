// src/components/Navbar.jsx
import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-gray-800 shadow-md fixed top-0 left-0 w-full z-50">
      <div className="max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo */}
          <NavLink to="/" className="text-3xl font-bold text-gray-100 flex items-center gap-2">
           <span className="hidden sm:inline font-extrabold"><span className='text-green-500'>S</span>to<span className='text-red-500'>c</span>k<span className='text-green-500'>D</span>eb<span className='text-red-500'>a</span>te</span>
          </NavLink>

          {/* Navigation Links */}
          <ul className="flex space-x-4 text-gray-200 font-medium">
            <li>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  isActive
                    ? 'text-blue-600 border-b-2 border-blue-600 pb-1'
                    : 'hover:text-blue-600 transition'
                }
              >
                Home
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/about"
                className={({ isActive }) =>
                  isActive
                    ? 'text-blue-600 border-b-2 border-blue-600 pb-1'
                    : 'hover:text-blue-600 transition'
                }
              >
                About
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/analyze"
                className={({ isActive }) =>
                  isActive
                    ? 'text-blue-600 border-b-2 border-blue-600 pb-1'
                    : 'hover:text-blue-600 transition'
                }
              >
                Analyze
              </NavLink>
            </li>
            <li>
              {/* <NavLink
                to="/adminpanel"
                className={({ isActive }) =>
                  isActive
                    ? 'text-blue-600 border-b-2 border-blue-600 pb-1'
                    : 'hover:text-blue-600 transition'
                }
              >
                Admin Panel
              </NavLink> */}
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
