// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import Analyze from './pages/Analyze';
import StockDebateSystem from './pages/Analyze1';
import "./App.css"
import TechnicalAnalysis from './pages/TechnicalAnalysis';
import RiskAnalysis from './pages/RiskAnalysis';
import FundamentalAnalysis from './pages/FundamentalAnalysis';

function App() {
  return (
    <div className='w-full'>
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/analyze1" element={<Analyze />} />
        <Route path='/analyze' element={<StockDebateSystem/>}/>
        <Route path='/tech' element={<TechnicalAnalysis ticker="AAPL"/>}/>
        <Route path='/risk' element={<RiskAnalysis ticker="AAPL"/>}/>
        <Route path='/funda' element={<FundamentalAnalysis />}/>
        {/* Add other routes here */}
      </Routes>
    </Router>
    </div>
    
  );
}

export default App;
