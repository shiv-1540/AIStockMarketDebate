from openai import OpenAI
import yfinance as yf

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="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",
)

def get_stock_summary(ticker):
    stock = yf.Ticker(ticker)
    info = stock.info
    summary = f"""
        Ticker: {ticker}
        Current Price: {info.get('currentPrice')}
        Sector: {info.get('sector')}
        Industry: {info.get('industry')}
        Market Cap: {info.get('marketCap')}
        Beta: {info.get('beta')}
        52 Week High: {info.get('fiftyTwoWeekHigh')}
        52 Week Low: {info.get('fiftyTwoWeekLow')}
    """.strip()
    return summary

def analyze_risk_openrouter(ticker):
    stock_info = get_stock_summary(ticker)

    prompt = (
        "Act as a senior financial risk analyst.\n\n"
        f"Below is the real-time stock summary:\n{stock_info}\n\n"
        "Based on this data, analyze the risk level, expected volatility, and any financial red flags an investor should be aware of. "
        "Give your answer in 4-5 lines only. Keep it precise, well-reasoned, and investment-focused. Do not explain what the data means; just give your concise risk analysis."
    )

    completion = client.chat.completions.create(
        model="microsoft/phi-4-reasoning:free",
        messages=[
            {"role": "user", "content": prompt}
        ],
        extra_headers={
            "HTTP-Referer": "http://localhost:3000",
            "X-Title": "AIStockMarket",
        },
    )

    return completion.choices[0].message.content.strip()

# Example usage
result = analyze_risk_openrouter("TSLA")
print(result)
