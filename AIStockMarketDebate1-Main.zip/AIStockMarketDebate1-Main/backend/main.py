from flask import Flask, request, jsonify
from openai import OpenAI
from stock_data_loader import get_stock_data
from agents.technical_agent import TechnicalAnalystAgent
from agents.fundamental_agent import FundamentalAnalystAgent
from agents.risk_agent import RisAgent
from agents.market_research_agent import MarketResearchAgent
from coordinator import CoordinatorAgent
from flask_cors import CORS  # Import CORS
import yfinance as yf
# from keras.models import load_model
# from sklearn.preprocessing import MinMaxScaler
import numpy as np

app = Flask(__name__)
API_KEY = "pub_2a02253db65c405fa4f88a8f3e2bc6ed"
openrouter_api_key="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"
CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}})

# Default route
@app.route("/", methods=["GET"])
def welcome():
    return jsonify({"message": "👋 Welcome to AIStock Debate System!"})

# @app.route("/fundamental",methods=["GET"])
def get_fundamental_data(ticker: str):
    try:
        stock = yf.Ticker(ticker)

        # Get Earnings Summary
        earnings_data = stock.financials
        revenue = earnings_data.loc["Total Revenue"][0]
        net_income = earnings_data.loc["Net Income"][0]
        earnings = f"Revenue: {revenue/1e9:.2f}B, Net Profit: {net_income/1e9:.2f}B"

        # Balance Sheet
        balance_sheet = stock.balance_sheet
        total_debt = balance_sheet.loc["Total Debt"][0]

        # P/E Ratio
        pe_ratio = stock.info.get("trailingPE", "N/A")
        pe_text = f"{pe_ratio} (P/E Ratio)"

        # Industry Info
        industry_info = stock.info.get("industry", "N/A")
        sector = stock.info.get("sector", "N/A")
        industry_summary = f"{sector} sector, {industry_info} industry shows steady growth trends."

        return {
            "ticker": ticker,
            "earnings": earnings,
            "net_income": float(net_income),
            "pe_ratio": pe_text,
            "industry_info": industry_summary
        }

    except Exception as e:
        return {"error": str(e)}
    
@app.route("/fundamentals/<ticker>", methods=["GET"])
def fundamentals_api(ticker):
    result = get_fundamental_data(ticker)
    return jsonify(result)




# def predict_next_7_days_bilstm(ticker):
#     # 1. Load model
#     # model = load_model("bilstm.h5")

#     # 2. Get historical close prices
#     df = yf.download(ticker, period="6mo", interval="1d")
#     if df.empty:
#         raise ValueError("No data for ticker")
    
#     close_prices = df['Close'].values.reshape(-1, 1)

#     # 3. Normalize
#     # scaler = MinMaxScaler()
#     scaled_close = scaler.fit_transform(close_prices)

#     # 4. Create last window (assume model trained on last 30 days)
#     last_30 = scaled_close[-30:]  # Shape (30, 1)
#     input_seq = np.expand_dims(last_30, axis=0)  # Shape (1, 30, 1)

#     # 5. Predict 7 future days iteratively
#     predictions = []
#     for _ in range(7):
#         pred = model.predict(input_seq)[0][0]  # Get scalar
#         predictions.append(pred)

#         # Append and slide the window
#         new_input = np.append(input_seq[0], [[pred]], axis=0)[-30:]
#         input_seq = np.expand_dims(new_input, axis=0)

#     # 6. Inverse transform
#     predicted_prices = scaler.inverse_transform(np.array(predictions).reshape(-1, 1)).flatten()

#     return predicted_prices.tolist()

# @app.route('/predict-next-7', methods=['GET'])
# def predict_next_7():
#     ticker = request.args.get('ticker')
#     if not ticker:
#         return jsonify({'error': 'Ticker symbol is required'}), 400

#     try:
#         predicted_prices = predict_next_7_days_bilstm(ticker)
#         return jsonify({
#             'ticker': ticker.upper(),
#             'predicted_next_7_days': predicted_prices
#         })
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500



def get_stock_data(ticker, period='1mo', interval='1d'):
    stock = yf.Ticker(ticker)
    data = stock.history(period=period, interval=interval)
    data.reset_index(inplace=True)
    return data.to_dict(orient='records')

@app.route('/stock-data', methods=['GET'])
def stock_data_api():
    ticker = request.args.get('ticker')
    period = request.args.get('period', '1mo')
    interval = request.args.get('interval', '1d')
    
    if not ticker:
        return jsonify({'error': 'Ticker symbol is required'}), 400

    try:
        data = get_stock_data(ticker, period, interval)
        return jsonify({'ticker': ticker, 'data': data})
    except Exception as e:
        return jsonify({'error str wala': str(e)}), 500
    


# OpenRouter client setup
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="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",
)
#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
#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
# Function to fetch stock summary
def get_stock_summary(ticker):
    stock = yf.Ticker(ticker)
    info = stock.info
    summary = f"""
    Ticker: {ticker}
    Current Price: {info.get('currentPrice')}
    Sector: {info.get('sector')}
    Industry: {info.get('industry')}
    Market Cap: {info.get('marketCap')}
    Beta: {info.get('beta')}
    52 Week High: {info.get('fiftyTwoWeekHigh')}
    52 Week Low: {info.get('fiftyTwoWeekLow')}
    """.strip()
    return summary

# Function to analyze risk using OpenRouter
def analyze_risk_openrouter(ticker):
    stock_info = get_stock_summary(ticker)

    prompt = (
        "Act as a senior financial risk analyst.\n\n"
        f"Below is the real-time stock summary:\n{stock_info}\n\n"
        "Based on this data, analyze the risk level, expected volatility, and any financial red flags an investor should be aware of. "
        "Give your answer in 3-4 lines only. Keep it precise, well-reasoned, and investment-focused. Do not explain what the data means; just give your concise risk analysis."
    )
    #meta-llama/llama-3.3-8b-instruct:free
    #tngtech/deepseek-r1t-chimera:free

    completion = client.chat.completions.create(
        model="meta-llama/llama-3.3-8b-instruct:free",
        messages=[{"role": "user", "content": prompt}],
        extra_headers={
            "HTTP-Referer": "http://localhost:5173",
            "X-Title": "AIStockMarket",
        },
    )

    return completion.choices[0].message.content.strip()

# Define API route
@app.route('/api/analyze-risk', methods=['POST'])
def analyze_risk_api():
    data = request.json
    ticker = data.get('ticker')

    if not ticker:
        return jsonify({'error': 'Ticker symbol is required'}), 400

    try:
        result = analyze_risk_openrouter(ticker)
        return jsonify({'ticker': ticker.upper(), 'analysis': result})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Debate route
@app.route("/api/stock/<ticker>", methods=["GET"])
def stock_debate(ticker):
    try:
        # 1. Get stock data
        data = get_stock_data(ticker)
        # print("Get data: ",data)
        # 2. Initialize agents
        agents = [
            # TechnicalAnalystAgent(),
            # FundamentalAnalystAgent(),
            RisAgent(),
            # MarketResearchAgent(api_key=API_KEY)
        ]
        print("Before hhiiii")
        # 3. Coordinate debate
        coordinator = CoordinatorAgent(agents)
        print("Hiii")   
        decision = coordinator.evaluate(ticker, data)

        return jsonify(decision)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
