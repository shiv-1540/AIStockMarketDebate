import requests
from transformers import pipeline

API_KEY = "pub_8435282bcaf3ab78a401fee58b8e8a0c8a441"
BASE_URL = "https://newsdata.io/api/1/news"

# Load sentiment classifier once
classifier = pipeline("sentiment-analysis", model="yiyanghkust/finbert-tone")

def fetch_news_and_sentiment(ticker: str, limit=10):
    params = {
        'apikey': API_KEY,
        'q': ticker,
        'country': 'in',
        'language': 'en',
        'category': 'business,technology'
    }
    response = requests.get(BASE_URL, params=params)
    data = response.json()

    if 'results' not in data:
        return {"error": "No news found"}

    articles = data['results'][:limit]

    # Analyze sentiment for each headline
    news_with_sentiment = []
    sentiments = {"positive": 0, "negative": 0, "neutral": 0}

    for article in articles:
        title = article.get('title', 'No Title')
        res = classifier(title)[0]  # e.g. {'label': 'positive', 'score': 0.99}

        label = res['label'].lower()
        if label == 'neutral':
            sentiments['neutral'] += 1
        elif label == 'positive':
            sentiments['positive'] += 1
        elif label == 'negative':
            sentiments['negative'] += 1

        news_with_sentiment.append({
            "headline": title,
            "sentiment": label,
            "score": round(float(res['score']), 4)
        })

    # Aggregate sentiment by max voting
    max_sentiment = max(sentiments, key=sentiments.get)

    return {
        "news": news_with_sentiment,
        "sentiment_summary": {
            "positive": sentiments['positive'],
            "negative": sentiments['negative'],
            "neutral": sentiments['neutral'],
            "dominant_sentiment": max_sentiment
        }
    }
