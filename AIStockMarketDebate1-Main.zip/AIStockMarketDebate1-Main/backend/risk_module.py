import yfinance as yf
import numpy as np

def risk_analysis(ticker: str, sentiment_summary: dict = None):
    data = yf.download(ticker, period="1mo", interval="1d")
    if data.empty:
        return {"error": "No data"}

    # Volatility as std dev of daily returns
    data['returns'] = data['Close'].pct_change()
    volatility = np.std(data['returns'].dropna())

    # Basic risk score: volatility weighted with negative news sentiment
    neg_sentiment = sentiment_summary.get('negative', 0) if sentiment_summary else 0
    total_sentiments = sum(sentiment_summary.values()) if sentiment_summary else 1
    neg_ratio = neg_sentiment / total_sentiments if total_sentiments else 0

    risk_score = volatility * (1 + neg_ratio)

    # Risk level threshold example
    if risk_score < 0.01:
        risk_level = "Low"
    elif risk_score < 0.03:
        risk_level = "Moderate"
    else:
        risk_level = "High"

    explanation = f"Volatility={volatility:.4f}, Negative News Ratio={neg_ratio:.2f}"

    return {
        "risk_score": round(float(risk_score), 4),
        "risk_level": risk_level,
        "explanation": explanation
    }
