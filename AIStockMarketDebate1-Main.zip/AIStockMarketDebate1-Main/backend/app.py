from flask import Flask, request, jsonify
from flask_cors import CORS
from lstm_module import lstm_predict
from tech_module import technical_analysis
from news_module import fetch_news_and_sentiment
from risk_module import risk_analysis

app = Flask(__name__)
CORS(app)

@app.route("/api/stock/<ticker>", methods=["GET"])
def analyze_stock(ticker):
    # lstm = lstm_predict(ticker)
    # tech = technical_analysis(ticker)
    news = fetch_news_and_sentiment(ticker)
    # risk = risk_analysis(ticker, news.get("sentiment_summary", {}))

    return jsonify({
        "ticker": ticker.upper(),
        # "lstm": lstm,
        # "technical": tech,
        # "news": news,
        # "risk": risk
    })

if __name__ == "__main__":
    app.run(debug=True)
