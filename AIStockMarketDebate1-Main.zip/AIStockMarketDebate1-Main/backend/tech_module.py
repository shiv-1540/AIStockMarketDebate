import yfinance as yf
import ta

def technical_analysis(ticker: str):
    data = yf.download(ticker, period="2mo", interval="1d")
    if data.empty:
        return {"error": "No data"}

    # Calculate indicators
    data['RSI'] = ta.momentum.RSIIndicator(data['Close']).rsi()
    macd = ta.trend.MACD(data['Close'])
    data['MACD'] = macd.macd()
    data['MACD_signal'] = macd.macd_signal()
    data['SMA_50'] = ta.trend.SMAIndicator(data['Close'], window=50).sma_indicator()
    data['EMA_20'] = ta.trend.EMAIndicator(data['Close'], window=20).ema_indicator()

    latest = data.iloc[-1]

    # Simple signal logic
    signal = "Hold"
    explanation = ""

    if latest['RSI'] < 30 and latest['MACD'] > latest['MACD_signal']:
        signal = "Buy"
        explanation = "RSI below 30 and MACD bullish crossover"
    elif latest['RSI'] > 70 or latest['MACD'] < latest['MACD_signal']:
        signal = "Sell"
        explanation = "RSI above 70 or MACD bearish crossover"
    else:
        explanation = "Indicators are neutral"

    indicators = {
        "RSI": round(float(latest['RSI']), 2),
        "MACD": round(float(latest['MACD']), 4),
        "MACD_signal": round(float(latest['MACD_signal']), 4),
        "SMA_50": round(float(latest['SMA_50']), 2),
        "EMA_20": round(float(latest['EMA_20']), 2)
    }

    return {
        "signal": signal,
        "indicators": indicators,
        "explanation": explanation
    }
