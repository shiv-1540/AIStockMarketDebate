import numpy as np
import pandas as pd
import yfinance as yf
import pickle
from datetime import datetime, timedelta
from tensorflow.keras.models import load_model
import ta

# Load model and scaler once
model = load_model('lstm_model_manual_rsi_macd.h5')
with open('scaler_manual_rsi_macd.pkl', 'rb') as f:
    scaler = pickle.load(f)

def lstm_predict(ticker: str):
    try:
        # Fetch 3 months of data for better indicator calculation
        data = yf.download(ticker, period="3mo", interval="1d")
        if data.empty or len(data) < 60:
            return {"error": "Not enough data available"}

        df = data.copy()
        df = df.sort_index()

        # Calculate indicators
        df['RSI'] = ta.momentum.RSIIndicator(df['Close']).rsi()
        macd = ta.trend.MACD(df['Close'])
        df['MACD'] = macd.macd()
        df['MACD_signal'] = macd.macd_signal()

        # Drop NaNs caused by indicator lag
        df = df.dropna()

        # Select only needed features
        features = df[['Close', 'RSI', 'MACD', 'MACD_signal']]
        scaled = scaler.transform(features)

        # Use last 60 days
        X_input = scaled[-60:]
        X_input = np.reshape(X_input, (1, 60, 4))

        # Predict
        pred_scaled = model.predict(X_input)

        # Inverse transform (fill rest with zeros for inverse scaling)
        dummy = np.zeros((1, 4))
        dummy[0, 0] = pred_scaled[0, 0]  # Only 'Close' is predicted
        inverse = scaler.inverse_transform(dummy)
        predicted_price = round(float(inverse[0, 0]), 2)

        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")

        return {
            "dates": [tomorrow],
            "predicted_prices": [predicted_price]
        }

    except Exception as e:
        return {"error": str(e)}


# import numpy as np
# import pandas as pd
# from datetime import datetime, timedelta

# def lstm_predict(ticker: str):
#     # Dummy prediction: Generate next 7 days prices with some random walk around current price
    
#     import yfinance as yf
#     data = yf.download(ticker, period="1mo", interval="1d")
#     if data.empty:
#         return {"error": "No data available"}

#     last_close = data['Close'].iloc[-1]
#     np.random.seed(42)
#     predictions = last_close + np.cumsum(np.random.randn(7))  # random walk

#     dates = [(datetime.now() + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(1, 8)]
#     predicted_prices = [round(float(p), 2) for p in predictions]

#     return {
#         "dates": dates,
#         "predicted_prices": predicted_prices
#     }
