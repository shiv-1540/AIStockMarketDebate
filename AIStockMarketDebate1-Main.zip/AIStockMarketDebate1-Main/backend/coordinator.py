class CoordinatorAgent:
    def __init__(self, agents):
        self.agents = agents

    def evaluate(self, ticker, data):
        decisions = []
        for agent in self.agents:
            result = agent.analyze(ticker, data)
            decisions.append(result)

        buy_votes = sum(1 for d in decisions if d["recommendation"] == "buy")
        final_recommendation = "buy" if buy_votes >= 1 else "hold"

        return {
            "ticker": ticker,
            "final_recommendation": final_recommendation,
            "agent_opinions": decisions
        }
