from flask import Flask, request, jsonify
import requests
import json

app = Flask(__name__)

# Function to scrape stock data
def scrape_stock_data():
    # Define the payload for the API request
    payload = {
        'api_key': 'bb9206e33dccbb0adbc1010140ce27ad',
        'url': 'https://finance.yahoo.com/',
        'output_format': 'json',
        'autoparse': 'true',
        'device_type': 'desktop'
    }

    # Make the API request
    response = requests.get('https://api.scraperapi.com/', params=payload)

    # Print the raw response text for debugging
    print("Raw response text:", response.text)

    # Check if the request was successful
    if response.status_code == 200:
        # Parse the JSON response
        try:
            data = response.json()
        except json.JSONDecodeError as e:
            print("JSON decode error:", e)
            return []

        # Inspect the structure of the response
        print("Parsed JSON data:", data)

        # Assuming the relevant stock data is in a specific part of the response
        stocks = data.get('stocks', [])  # Adjust this key based on the actual response structure

        # Prepare the output list
        output = []

        # Extract relevant information for each stock
        for stock in stocks:
            # Adjust the keys based on the actual structure of the stock data
            stock_info = {
                "symbol": stock.get("symbol", "unknown"),
                "market": stock.get("market", "unknown"),
                "risk": stock.get("risk", "unknown"),
                "timeframe": stock.get("timeframe", "unknown"),
                "price": stock.get("price", 0.0),
                "change_percent": stock.get("change_percent", 0.0),
                "description": stock.get("description", "No description available.")
            }
            output.append(stock_info)

        return output
    else:
        print(f"Error: {response.status_code} - {response.text}")
        return []

# Global variable to store scraped data
scraped_data = scrape_stock_data()

@app.route('/api/scrape', methods=['GET'])
def scrape_api():
    # Call the scrape_stock_data function to get the latest stock data
    stock_data = scrape_stock_data()
    
    # Return the scraped data as a JSON response
    return jsonify(stock_data)

@app.route('/api/top3', methods=['POST'])
def get_top_stocks():
    data = request.json
    market = data.get('market')
    risk = data.get('risk')
    timeframe = data.get('timeframe')

    # Filter stocks based on the input criteria
    filtered_stocks = [
        stock for stock in scraped_data
        if stock['market'] == market and stock['risk'] == risk and stock['timeframe'] == timeframe
    ]

    # Sort stocks by change_percent (you can adjust the sorting criteria as needed)
    sorted_stocks = sorted(filtered_stocks, key=lambda x: x['change_percent'], reverse=True)

    # Get the top 3 stocks
    top_stocks = sorted_stocks[:3]

    return jsonify(top_stocks)

if __name__ == '__main__':
    app.run(debug=True)
